// ADMIN LOGIN PAGE

package Frame;

import java.lang.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class AdminLogin extends JFrame implements ActionListener
{
	JPanel panel;
	JLabel label;
	JTextField namefld;;
	JPasswordField passfld;;
	JButton loginbtn, backbtn;
	ImageIcon  img1,img2,img3;

	AdminLogin()
	{

		
		super("Admin Login");
		this.setSize(1010,555);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);

		
		img1 = new ImageIcon("Images/adminpanel.png");
		label = new JLabel(img1);
		label.setBounds(0, 0, 1000, 550);
		panel.add(label);

	
        namefld = new JTextField();
        namefld.setFont(new  Font("Comic Sans MS",Font.PLAIN,25));
        namefld.setBounds(380,265,232,35);
        namefld.setOpaque(false);
        namefld.setForeground(Color.BLACK);
        namefld.setBorder(BorderFactory.createEmptyBorder());
        label.add(namefld);
		
		passfld = new JPasswordField();
        passfld.setFont(new  Font("Comic Sans MS",Font.PLAIN,20));
        passfld.setBounds(385,338,232,35);
        passfld.setOpaque(false);
        passfld.setForeground(Color.BLACK);
        passfld.setBorder(BorderFactory.createEmptyBorder());
        passfld.setEchoChar('*');
		label.add(passfld);
		
	    img2 = new ImageIcon("Images/adminlogin.png");
		loginbtn = new JButton(img2);
		loginbtn.setBounds(700,338,102,32);
		loginbtn.addActionListener(this);
		label.add(loginbtn);
		
		
		img3 = new ImageIcon("Images/backbtn.png");
		backbtn = new JButton(img3);
		backbtn.setBounds(850,465,102,32);
		backbtn.addActionListener(this);
		label.add(backbtn);

		this.add(panel);	

		
		
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String s1=namefld.getText();
		String s2=passfld.getText();
		
		if(ae.getSource() == backbtn)
		{
			form1 f= new form1();
			f.setVisible(true);
			this.setVisible(false);
		}
		else if(ae.getSource()==loginbtn)
		{
			if(s1.isEmpty() || s2.isEmpty())
			{
				JOptionPane.showMessageDialog(this, "Fill up all first");
			}

			else if(s1.equals("admin") && s2.equals("admin"))
			{
				AdminPage a1 = new AdminPage();
				a1.setVisible(true);
				this.setVisible(false);
			}
			else
			{
					JOptionPane.showMessageDialog(this, "Incorrect Username or Password");
			}
		}
	}

	
}
