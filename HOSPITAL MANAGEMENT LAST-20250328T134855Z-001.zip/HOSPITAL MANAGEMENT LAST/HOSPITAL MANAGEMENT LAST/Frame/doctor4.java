// Doctor 4

package Frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class doctor4 extends JFrame
{
	JPanel panel;
	JLabel label;
	ImageIcon img1;
	
	
	doctor4()
	{
		super("Doctor-4 Details");	
		this.setSize(650, 400);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		img1= new ImageIcon("Images/d4.png");
		
		label = new JLabel(img1);
		label.setBounds(0, 0, 650, 400);
		panel.add(label);
		
		this.add(panel);
		
	}


}
