package Frame;

import javax.swing.*;

import Classes.Account;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;

public class DonorRegistration extends JFrame implements ActionListener {
    JPanel panel;
    JLabel titleLabel, nameLabel, mobileLabel, bloodGroup, passLabel;
    JTextField namefld, mobilefld, bloodGroupfld;
    JPasswordField passfld;
    JButton registerbtn, backbtn;

    DonorRegistration() {
        super("Donor Registration");
        this.setSize(500, 450);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(new Color(0xDDEEFF));

        titleLabel = new JLabel("Donor Registration");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 30));
        titleLabel.setBounds(100, 20, 300, 50);
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(titleLabel);

        nameLabel = new JLabel("Username:");
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        nameLabel.setBounds(50, 100, 100, 25);
        panel.add(nameLabel);

        namefld = new JTextField();
        namefld.setFont(new Font("Arial", Font.PLAIN, 18));
        namefld.setBounds(160, 100, 200, 30);
        panel.add(namefld);

        mobileLabel = new JLabel("Mobile:");
        mobileLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        mobileLabel.setBounds(50, 150, 100, 25);
        panel.add(mobileLabel);

        mobilefld = new JTextField();
        mobilefld.setFont(new Font("Arial", Font.PLAIN, 18));
        mobilefld.setBounds(160, 150, 200, 30);
        panel.add(mobilefld);


        bloodGroup = new JLabel("Blood Group:");
        bloodGroup.setFont(new Font("Arial", Font.PLAIN, 18));
        bloodGroup.setBounds(50, 250, 100, 25);
        panel.add(bloodGroup);

        bloodGroupfld = new JTextField();
        bloodGroupfld.setFont(new Font("Arial", Font.PLAIN, 18));
        bloodGroupfld.setBounds(160, 250, 200, 30);
        panel.add(bloodGroupfld);

        passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        passLabel.setBounds(50, 300, 100, 25);
        panel.add(passLabel);

        passfld = new JPasswordField();
        passfld.setFont(new Font("Arial", Font.PLAIN, 18));
        passfld.setBounds(160, 300, 200, 30);
        passfld.setEchoChar('*');
        panel.add(passfld);

        registerbtn = new JButton("Register");
        registerbtn.setFont(new Font("Arial", Font.BOLD, 16));
        registerbtn.setBounds(160, 350, 100, 30);
        registerbtn.addActionListener(this);
        registerbtn.setBackground(new Color(0x2E8B57));
        panel.add(registerbtn);

        backbtn = new JButton("Back");
        backbtn.setFont(new Font("Arial", Font.BOLD, 16));
        backbtn.setBounds(270, 350, 100, 30);
        backbtn.addActionListener(this);
        backbtn.setBackground(new Color(0x8B0000));
        panel.add(backbtn);

        this.add(panel);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == registerbtn) {
            String name = namefld.getText();
            String mobile = mobilefld.getText();
            String bloodGroup = bloodGroupfld.getText();
            String pass = new String(passfld.getPassword());

            if (name.equals("") || mobile.equals("") || bloodGroup.equals("") || pass.equals("")) {
                JOptionPane.showMessageDialog(this, "Please fill all the fields", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                Account donor = new Account(name, mobile, bloodGroup, pass);
                donor.addDonorAccount();
                JOptionPane.showMessageDialog(this, "Registration Successful", "Success", JOptionPane.INFORMATION_MESSAGE);
                this.setVisible(false);
                new DonorLogin().setVisible(true);
            }
        } else if (ae.getSource() == backbtn) {
            this.setVisible(false);
            new DonorLogin().setVisible(true);
        }
    }

    public static void main(String[] args) {
        DonorRegistration d = new DonorRegistration();
        d.setVisible(true);
    }
}
