// GET STARTED PAGE

package Frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class form extends JFrame implements ActionListener
{
	JPanel panel;
	JLabel label;
	JButton button;
	ImageIcon img1, img2, img3;
	
	
	public form()
	{
		super("Diagnose Your Health");	
		this.setSize(1000, 580);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		img1 = new ImageIcon("Images/logo1.png");
        this.setIconImage(img1.getImage());

        

		panel = new JPanel();
		panel.setLayout(null);
		
		img2= new ImageIcon("Images/welcome.gif");
		
		label = new JLabel(img2);
		label.setBounds(0, 0, 1000, 550);
		panel.add(label);

        img3 = new ImageIcon("Images/getStart.png");
		button = new JButton(img3);
		button.setBounds(690,380,226,67); 
        button.addActionListener(this);
		label.add(button);
		

		
		this.add(panel);
		
	}


	public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==button)
			{
			    form1 f = new form1();
				this.setVisible(false);
				f.setVisible(true);
			}

		}


}
