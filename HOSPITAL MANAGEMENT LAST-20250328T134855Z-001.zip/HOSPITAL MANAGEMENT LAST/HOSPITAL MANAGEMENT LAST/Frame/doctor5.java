// Doctor 5

package Frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class doctor5 extends JFrame
{
	JPanel panel;
	JLabel label;
	ImageIcon img1;
	
	
	doctor5()
	{
		super("Doctor-5 Details");	
		this.setSize(650, 400);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		img1= new ImageIcon("Images/d5.png");
		
		label = new JLabel(img1);
		label.setBounds(0, 0, 650, 400);
		panel.add(label);
		
		this.add(panel);
		
	}


}
