// Doctor 1

package Frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class doctor1 extends JFrame
{
	JPanel panel;
	JLabel label;
	ImageIcon img1;
	
	
	doctor1()
	{
		super("Doctor-1 Details");	
		this.setSize(650, 400);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		img1= new ImageIcon("Images/d1.png");
		
		label = new JLabel(img1);
		label.setBounds(0, 0, 650, 400);
		panel.add(label);
		
		this.add(panel);
		
	}


}
