// ADMIN PAGE

package Frame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.DefaultTableModel;
import java.util.*;
import java.io.*;

public class AdminPage extends JFrame implements ActionListener, MouseListener 
{
    JPanel panel;
    JLabel label;
    JTextField namefld, mobilefld, emailfld, passfld;
    JButton addbtn, updatebtn, deletebtn, clearbtn, backbtn;
    ImageIcon img1, img2, img3, img4, img5, img6;
    JTable table;
    JScrollPane scroll;
    DefaultTableModel model;

    private String[] columns = {"Name", "Phone Number", "Email", "Password"};
    private String[] rows = new String[4]; 

    AdminPage() 
    {

        super("Admin Management");
        this.setSize(1010, 555);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setLayout(null);

        img1 = new ImageIcon("Images/adminmanagement.png");
        label = new JLabel(img1);
        label.setBounds(0, 0, 1000, 550);
        panel.add(label);

        img2 = new ImageIcon("Images/addbtn.png");
        addbtn = new JButton(img2);
        addbtn.setBounds(415, 434, 98, 32);
        addbtn.addActionListener(this);
        label.add(addbtn);

        img3 = new ImageIcon("Images/updatebtn.png");
        updatebtn = new JButton(img3);
        updatebtn.setBounds(300, 434, 98, 32);
        updatebtn.addActionListener(this);
        label.add(updatebtn);

        img4 = new ImageIcon("Images/deletebtn.png");
        deletebtn = new JButton(img4);
        deletebtn.setBounds(185, 434, 98, 32);
        deletebtn.addActionListener(this);
        label.add(deletebtn);

        img5 = new ImageIcon("Images/clearbtn.png");
        clearbtn = new JButton(img5);
        clearbtn.setBounds(70, 434, 98, 32);
        clearbtn.addActionListener(this);
        label.add(clearbtn);

        img6 = new ImageIcon("Images/backbtn.png");
        backbtn = new JButton(img6);
        backbtn.setBounds(840, 450, 100, 32);
        backbtn.addActionListener(this);
        label.add(backbtn);

        namefld = new JTextField();
        namefld.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
        namefld.setBounds(180, 157, 280, 30);
        namefld.setOpaque(false);
        namefld.setForeground(Color.BLUE);
        namefld.setBorder(BorderFactory.createEmptyBorder());
        label.add(namefld);

        mobilefld = new JTextField();
        mobilefld.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
        mobilefld.setBounds(180, 220, 280, 30);
        mobilefld.setOpaque(false);
        mobilefld.setForeground(Color.BLUE);
        mobilefld.setBorder(BorderFactory.createEmptyBorder());
        label.add(mobilefld);

        emailfld = new JTextField();
        emailfld.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
        emailfld.setBounds(180, 286, 280, 30);
        emailfld.setOpaque(false);
        emailfld.setForeground(Color.BLUE);
        emailfld.setBorder(BorderFactory.createEmptyBorder());
        label.add(emailfld);

        passfld = new JTextField();
        passfld.setFont(new Font("Comic Sans MS", Font.PLAIN, 20));
        passfld.setBounds(180, 353, 280, 30);
        passfld.setOpaque(false);
        passfld.setForeground(Color.BLUE);
        passfld.setBorder(BorderFactory.createEmptyBorder());
        label.add(passfld);

        table = new JTable();
        model = new DefaultTableModel();
        model.setColumnIdentifiers(columns);
        table.setModel(model);
        table.setRowHeight(30);
        table.addMouseListener(this); // Add MouseListener to the table

        scroll = new JScrollPane(table);
        scroll.setBounds(520, 130, 450, 300);
        label.add(scroll);

        loadInformation();

        this.add(panel);
    }

    
    public void mouseClicked(MouseEvent me) 
    {

        if (me.getSource() == table) 
        {

            int numberOfRow = table.getSelectedRow();
            if (numberOfRow >= 0) 
            {

                String getName = model.getValueAt(numberOfRow, 0).toString();
                String getPhone = model.getValueAt(numberOfRow, 1).toString();
                String getEmail = model.getValueAt(numberOfRow, 2).toString();
                String getPass = model.getValueAt(numberOfRow, 3).toString();

                namefld.setText(getName);
                mobilefld.setText(getPhone);
                emailfld.setText(getEmail);
                passfld.setText(getPass);

            }
        }
    }

   

    public void mousePressed(MouseEvent me) {}

    public void mouseReleased(MouseEvent me) {}
   
    public void mouseEntered(MouseEvent me) {}
    
    public void mouseExited(MouseEvent me) {}

    Scanner sc;
    File file = new File(".\\Datas\\userData.txt");

    public void loadInformation() 
    {

        try 
        {

            sc = new Scanner(file);

            while (sc.hasNextLine()) 
            {
                String line = sc.nextLine();
                String[] value = line.split("\t");
                model.addRow(value);
            }
        } 

        catch (IOException ioe) 
        {
            ioe.printStackTrace();
        }
    }

    
    public void actionPerformed(ActionEvent ae) 
    {

        String name = namefld.getText();
        String mobile = mobilefld.getText();
        String email = emailfld.getText();
        String password = passfld.getText();

        if (ae.getSource() == addbtn) 

        {
            if (name.isEmpty() || mobile.isEmpty() || email.isEmpty() || password.isEmpty()) 
            {
                JOptionPane.showMessageDialog(this, "Fill up all fields first");
            } 

            else 
            {
                rows[0] = name;
                rows[1] = mobile;
                rows[2] = email;
                rows[3] = password;
                model.addRow(rows);

                writeToFile();
            }
        } 

        else if (ae.getSource() == clearbtn) 
        {

            namefld.setText("");
            mobilefld.setText("");
            emailfld.setText("");
            passfld.setText("");

        } 
        
        else if (ae.getSource() == deletebtn) 
        {

            int numberOfRow = table.getSelectedRow();

            if (numberOfRow >= 0) 
            { 

                model.removeRow(numberOfRow);
                writeToFile();

            } 

            else 
            {
                JOptionPane.showMessageDialog(this, "No row has been selected!");
            }

        } 

        else if (ae.getSource() == updatebtn) 
        {
            int numberOfRow = table.getSelectedRow();
            if (numberOfRow >= 0) {
                model.setValueAt(name, numberOfRow, 0);
                model.setValueAt(mobile, numberOfRow, 1);
                model.setValueAt(email, numberOfRow, 2);
                model.setValueAt(password, numberOfRow, 3);

                writeToFile();
            } 

            else 
            {
                JOptionPane.showMessageDialog(this, "No row has been selected for update!");
            }
        } 

        else if (ae.getSource() == backbtn) 
        {
            AdminLogin al = new AdminLogin();
            al.setVisible(true);
            this.setVisible(false);
        }
    }

    public void writeToFile() 
    {

        try (FileWriter fwrite = new FileWriter(".\\Datas\\userData.txt")) 
        {

            for (int i = 0; i < model.getRowCount(); i++) 
            {

                for (int j = 0; j < model.getColumnCount(); j++) 
                {

                    fwrite.write(model.getValueAt(i, j).toString());
                    if (j != model.getColumnCount() - 1) {
                        fwrite.write("\t");

                    }
                }

                fwrite.write("\n");
            }

        } 

        catch(IOException ioe)
        {
            ioe.printStackTrace();
        }
    }
}