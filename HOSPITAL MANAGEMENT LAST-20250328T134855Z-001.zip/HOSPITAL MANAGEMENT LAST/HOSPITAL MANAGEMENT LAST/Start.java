import Frame.*;
import Classes.*;


public class Start 
{
	public static void main(String args[])
	{
		form f1 = new form();
		f1.setVisible(true);
	}
}